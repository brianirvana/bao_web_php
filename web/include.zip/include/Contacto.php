<? include ("functions.php"); 
 contacto(); ?>
<?php

/*include("../include/config.php");
$db = mysql_connect($dbhost,$dbusername,$dbpass); 
mysql_select_db($dbname) or die($dberror);
$ip = $_SERVER['REMOTE_ADDR'];
for ($i = 0; $i <= 5; $i++) {
     $Nombre[$i] 	= $_POST['Nombre'.$i];
	 $Min[$i] 		= $_POST['Min'.$i];
	 $Max[$i] 		= $_POST['Max'.$i];
	 $Media[$i] 	= $_POST['Media'.$i];
	 $Loss[$i] 		= $_POST['Loss'.$i];
	 mysql_query("INSERT INTO isptest(Nombre, Min, Max, Media, Loss, IP) VALUES('$Nombre[$i]','$Min[$i]','$Max[$i]', '$Media[$i]', '$Loss[$i]', '$ip')"); 
}*/

?>
<?
$usuarios_sesion="Staff";
$sql_host="localhost";
$sql_usuario="benderao_user";
$sql_pass="x#KOm,2!*+Si";
$sql_db="benderao_web";
$sql_tabla="usuarios";
?>

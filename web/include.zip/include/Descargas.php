<html>
<head><meta charset="windows-1252">

    <link rel="shortcut icon" href="http://www.bender-online.com.ar/bender/images/favicon.ico" type="image/x-icon" />
</head>
    
Cliente Completo necesario para jugar (Es lo mismo cualquiera de las opciones):

<br>
<b>Descargar Juego Completo (Actualizado: 17/05/2022 12:00):
<b>
<a href="https://www.mediafire.com/file/rp2w4ednlvpoft2/Bender-Online.exe/file" target="_blank">
<a href="https://www.mediafire.com/file/rp2w4ednlvpoft2/Bender-Online.exe/file" target="_blank"><img border="0" src="images/descargas_080.gif"></a></b><br>Descargas totales: 976
<br>
<br>

<b>Descargar Juego Completo (Actualizado: 17/05/2022 12:00):
<b>
<a href="https://bender-online.com.ar/downloads/Bender-Online.exe" target="_blank">
<a href="https://bender-online.com.ar/downloads/Bender-Online.exe" target="_blank"><img border="0" src="images/descargas_080.gif"></a></b><br>Descargas totales: 519126
<br>
<br>

&iquest;No entiendes c&oacutemo validar tu e-mail&#63; <br>
Mir&aacute; el siguiente video tutorial en youtube (Clic aqu�):<br>
</font></b></b>

<object width="425" height="344"><param name="movie" value="http://www.youtube.com/v/9VpDO5RNECE&hl=es&fs=1&rel=0"></param><param name="allowFullScreen" value="true"></param><embed src="http://www.youtube.com/v/9VpDO5RNECE&hl=es&fs=1&rel=0" type="application/x-shockwave-flash" allowfullscreen="true" width="425" height="344"></embed></object>

<br>
<br>
Requisitos m&iacute;nimos y recomendados del Sistema para poder jugar BenderAO:
<br>
 <table width="50%" border="0" cellspacing="2" cellpadding="2">

    <tr>
      <td width="20%" align="center" bgcolor="#000000"><strong><font size="1" color="white">Componente</font></strong></td>
      <td width="40%" align="center" bgcolor="#000000"><strong><font size="1" color="white">M&iacute;nimos</font></strong></td>
      <td width="40%" align="center" bgcolor="#000000"><strong><font size="1" color="white">Recomendados</font></strong></td>
    </tr>
    <tr>
      <td width="20%" align="right" bgcolor="#000000"><strong><font size="1" color="white">Procesador:</font></strong></td>

      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FF00">Intel Pentium II 500MHz o equivalentes/superiores.</font></em></td>
      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FFFF">Intel Pentium III 750MHz o equivalentes/superiores.</font></em></td>
    </tr>
    <tr>
      <td width="20%" align="right" bgcolor="#000000"><strong><font size="1" color="white">Memoria Ram:</font></strong></td>
      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FF00">128MB(para windows 98, 2000 ME, XP), 256MB(Para windows vista o 7)</font></em></td>
      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FFFF">512MB(para windows 98, 2000 ME, XP), 
		512MB(Para windows vista o 7)</font></em></td>

    </tr>
    <tr>
      <td width="20%" align="right" bgcolor="#000000" ><strong><font size="1" color="white">Espacio en Disco:</font></strong></td>
      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FF00">160MB Libres aproximadamente.</font></em></td>
      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FFFF">250MB Libres aproximadamente.</font></em></td>
    </tr>
    <tr>

      <td width="20%" align="right" bgcolor="#000000"><strong><font size="1" color="white">Placa de Video:</font></strong></td>
      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FF00">32MB Compatible con DirectX7</font></em></td>
      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FFFF">128MB Compatible con DirectX7</font></em></td>
    </tr>
    <tr>
      <td width="20%" align="right" bgcolor="#000000"><strong><font size="1" color="white">Controladores:</font></strong></td>
      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FF00">Teclado y Mouse.</font></em></td>

      <td width="40%" bgcolor="#333333"><em><font size="1" color="#00FFFF">Teclado, Mouse</font></em></td>
    </tr>
    <tr>
      <td align="right" bgcolor="#000000"><strong><font size="1" color="white">Sistema Operativo:</font></strong></td>
      <td bgcolor="#333333"><em><font size="1" color="#00FF00">Plataforma windows XP o superior</font></em></td>
      <td bgcolor="#333333"><em><font size="1" color="#00FFFF">Plataforma windows 7 o superior</font></em></td>
    </tr>

  </table>

<br>

</html>
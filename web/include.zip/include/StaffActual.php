c<?
    mb_http_output("windows-1252");
    header("Content-Type: text/html; charset=". mb_http_output());
?>

<html>
<head><meta charset="windows-1252">
<meta http-equiv="Content-Language" content="es">
</head>

<p align="center">
	<a href="JavaScript:DelDiv()">
	<span style="text-decoration: none; font-weight: 700">Volver</span></a><b><font color="#008000">
	</font></b>
</p>

<p align="center"><b><font size="4">Idea original</font></b><br>
	Gulfas Morgolock (Creador de Argentum Online)<br>
	Allport (Creador del mod de Argentum Online: BenderAO)<br>
	
	<font color="#0099FF">
	<b>Director del Proyecto</b><br>
	About<br></font>
	<br>
	<u>
	<b><font size="4">Staff de Game Masters</font></b></u><br>
	<br>
	<b>Directores de Game Masters</b><br>
	LeaWaney<br>
	<br>
	<b><font size="4">Coordinadores</font></b><br>
	Claybroke<br>
	<br>
	<b><font size="4">Coordinador de Eventos</font></b><br>
	VesslaN<br>
	<b><font size="4">Coordinador de Soporte</font></b><br>
	Hunzik<br>
<b><font size="4">Game Masters</font></b><br>
Hunzik<br>
Vesslan<br>
<br>
<b><font size="4">Consejeros</font></b><br>
Fenicio<br>
Blou<br>
<br>
<b><font size="4">Director de Role Masters</font></b><br>
Maetsuki<br>
<br>
<b><font size="4">Coordinadores de Role Masters</font></b><br>
Kimmy<br>
<br>
<b><font size="4">Role Masters</font></b><br>
Kimmy<br>
Maetsuki<br>
<u><b><font size="4">Staff de Desarrollo</font></b></u><br>
<br>
<b><font size="4">Director de Desarrollo</font></b><br>
About<br>
<b><font size="4">Coordinaci�n de Desarrollo</font></b><br>
Kuruk<br>
<b><font size="4">Staff de Balance</font></b><br>
About<br>
Kuruk<br>
Leawaney<br>
Claybroke<br>
Maetsuki<br>
<br>
<b><font size="4">Game Design</font></b><br>
About<br>
Kuruk<br>
<br>
<b><font size="4">Programaci�n (Hist�ricos)</font></b><br>
About<br>
Kuruk<br>
Loopzer<br>
Dark Thom<br>
Shak<br>
GS<br>
<br>
<b><font size="4">Ambientaci�n</font></b><br>
About<br>
Kuruk<br>
Cerridwen<br>
Midgard<br>
Togue<br>
<br>
<b><font size="4">�rea Indexaci�n</font></b><br>
Kimmy<br>
<br>
<b><font size="4">�rea Mapeo</font></b><br>
About<br>
KuruK<br>
Leawaney<br>
Cerridwen<br>
<br>
<b><font size="4">�rea Sonidos</font></b><br>
Alejandro Yanni (Masterizaci�n, mix, composici�n, sonidos originales)<br>
About (Direcci�n)<br>
<br>
<b><font size="4">�rea Graficaci�n</font></b><br>
About<br>
Kuruk<br>
Togue<br>
Cerridwen<br>
<br>
<b><font size="4">�rea Dateo</font></b><br>
About<br>
Kuruk<br>
K enano<br>
Leawaney<br>
Claybroke<br>
Maetsuki<br>
<br>
<b><font size="4">Staff de Prensa</font></b><br>
Leawaney<br>
Vesslan<br>
Santo<br>
Alikur<br>
Maetsuki<br>
Claybroke<br>
<br>
</p>

<br>
<b><font size="4">Webmastering<br>
</font></b>Kuruk<br>
About<br>
Kuruk<br>
Claybroke<br>
Maetsuki<br>
Leawaney<br>
<br>
<b><font size="4">Webdesing</font></b><br>
ElNiCk (Creador)<br>
Kuruk<br>
About (Jefe)<br>
Parmenido<br>
Raditz<br>
Togue<br>
<p align="center">
<b><font size="4">Moderaci�n en Foro</font></b><br>
About (Administrador)<br>
<br>
<b><font size="5">El Staff de BenderAO agradece a la siguientes personas:</font></b><br>
MaTeO, Andres (Claybroke), Eze Badof, Nico Esposito, Lucas Fermoselle (Minehost.com.ar), <br>
Nico (Pipita Higuain), Mariano Brocal (SANTO), Nacho (Vesslan), Tomi Berkum,<br>
Zaire V., Matias (Fenicio), Laza Baez (Kimmy), Facundo Acevedo (Alikur)<br>
Agustin Giovanoli (Valhalla), Lucas Pi�eiro (Hunzik), Eros Carril, Ariel Bulacio, <br>
Tato Cabalaro, Fede Moreno, Mini (Kun Aguero),//F\\, BLuR!, Brear, Narok, ASiGNiF,<br>
Frouth, emanueel, Exilied, Bks, the Gasthy, pAliito, Zozil, Finer, Link, Nokke,<br>
Juana La Loca, eDman, Bauty, Vikingo I, akatshuki, Webing, Zizter, Nitro Oxide,<br> 
gluk el pirata, Darakan, slowpoke, Lukky, Silent, Shira, Lord Fers, fEDEPS, VALSEN,<br>
Lanzers, ironik7, jasar, On Fire, kev, -Spirok-, Crixis, MacVeil<br><br><br>

Por toda la ayuda brindada en el desarrollo de la versi�n v0.4.0 desde diciembre 
de 2010 hasta la actualidad, simplemente: gracias.<br>

</p>

<b><font size="5">El Staff de BenderAO tambi�n agradece a la siguientes personas:</font></b><br>

XPROCESS09 por su magn�fico sistema de campa�as, implementado en 2014 en BenderAO,<br> 
con fuertes modificaciones protocolares por el Staff de desarrollo de Bender, <br>
pero conservando la est�tica original del sistema y todas sus cualidades (y a�n m�s).

</p> 
<p align="center">

<a href="?op=StaffActual" onclick="window.scrollTo(0,0); return false">
(ir arriba)</a><font color="#008000"> </font>
</p>
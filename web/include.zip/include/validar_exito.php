<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="shortcut icon" href="http://www.benderao.arghosted.com/web/images/favicon.ico" type="image/x-icon" />
</head>

<p align="center"><b><font size="4">�EXCELENTE!</font></b><br>
	Tu direcci�n de e-mail, ha sido verificada con �xito.<br>
	<br>
	<br>
	Ahora tienes los siguientes beneficios dentro del juego:<br><br>
	
	- <b>�Puedes Invitar amigos a jugar BenderAO!</b><br>
	  Info: Desde el panel de tu cuenta de BenderAO, hay un bot�n (INVITAR AMIGO) el cual poniendo el e-mail de un amigo tuyo, creas autom�ticamente una invitaci�n 
	  para tu amigo. Si tu amigo acepta �sta invitaci�n (simplemente haciendo clic en un link que le enviaremos nosotros de forma autom�tica), y se crea una cuenta
	  y un personaje, entonces recibir�s un PREMIO por hacerlo (tu amigo recibir� el mismo premio).
	  A medida que invites m�s amigos, el premio ser� cada vez mejor.<br>
	  <br>
	- <b>�Bonus en Party con Amigos!</b><br>
	  Info: Con TODOS los amigos que hayas invitado a jugar, podr�s hacer Party con un bouns ESPECIAL de 100% para t� y tu amigo al mismo tiempo.<br>
	  <br>
	- <b>Podr�s acceder al sistema de recuperar contrase�as, cambiar contrase�a de tu cuenta, y recuperar el nombre de tu cuenta (En caso de que te olvides alguno) </b><br>
	  <br>
	- <b>Puedes activar seguridad extra para tu cuenta, con el comando /ACTIVARSEGURIDAD</b><br>
	  Info: Con �sta opci�n activada, s�lo puedes acceder a tu cuenta desde la computadora (� PC) donde has creado tu cuenta de BenderAO.
	  Si alguien intenta ingresar a tu cuenta, te enviaremos un e-mail notific�ndote de �sto, y puedes accederle permiso para ingreasr en TU cuenta a esa persona
	  haciendo simplemente clic en un link.<br>
	  <br>
</p> 

<p align="center">
	<a href="?op=StaffActual" onclick="window.scrollTo(0,0); return false">
	(ir arriba)</a><font color="#008000"> </font>
</p>
<?php

global $id;
global $tipo;
$dbhost = "localhost";
$dbname = "benderao_web";
$dbusername = "benderao_user";
$dbpass = "x#KOm,2!*+Si";
	
// Charset
$charset = "uft-8";
$textchars = 480;
$tekst_datum = "d-m-Y";
$start = 0;
$end = 6;
$image_folder = "img";
$mail="Staff.Bender2@Gmail.com";
$site="Bender AO";

$dberror = "Error 321111 conectando a la base de datos!";

?>
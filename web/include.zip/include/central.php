<?
include ("functions.php"); 
 center(); 
?>
<?php
global $u;
global $p;
global $s;
global $e;
global $o;
$dbhost = "localhost";
$dbname = "benderao_web";
$dbusername = "benderao_user";
$dbpass = "x#KOm,2!*+Si";
$dberror = "Error 321 conectando a la base de datos";
?>
<?php
// 0 = Gnomo
// 1 = Elfo Oscuro
// 2 = Elfo
// 3 = Humano
// 4 = Enano

// Magos
$promedios[0][0] = 5.75;
$promedios[0][1] = 5.75;
$promedios[0][2] = 6.47;
$promedios[0][3] = 6.74;
$promedios[0][4] = 7.5;

//Clerigo
$promedios[1][0] = 7.49;
$promedios[1][1] = 7.49;
$promedios[1][2] = 7.7;
$promedios[1][3] = 8.45;
$promedios[1][4] = 8.69;

//Guerrero
$promedios[2][0] = 8.67;
$promedios[2][1] = 8.67;
$promedios[2][2] = 9.43;
$promedios[2][3] = 9.66;
$promedios[2][4] = 10.42;

//Asesino
$promedios[3][0] = 7.49;
$promedios[3][1] = 7.49;
$promedios[3][2] = 7.7;
$promedios[3][3] = 8.45;
$promedios[3][4] = 8.69;

//Ladron
$promedios[4][0] = 7.49;
$promedios[4][1] = 7.49;
$promedios[4][2] = 7.7;
$promedios[4][3] = 8.45;
$promedios[4][4] = 8.69;

//Bardo
$promedios[5][0] = 7.49;
$promedios[5][1] = 7.49;
$promedios[5][2] = 7.7;
$promedios[5][3] = 8.45;
$promedios[5][4] = 8.69;

//Druida
$promedios[6][0] = 7.49;
$promedios[6][1] = 7.49;
$promedios[6][2] = 7.7;
$promedios[6][3] = 8.45;
$promedios[6][4] = 8.69;

//Bandido
$promedios[7][0] = 7.49;
$promedios[7][1] = 7.49;
$promedios[7][2] = 7.7;
$promedios[7][3] = 8.45;
$promedios[7][4] = 8.69;

//Paladin
$promedios[8][0] = 8.42;
$promedios[8][1] = 8.42;
$promedios[8][2] = 8.79;
$promedios[8][3] = 9.41;
$promedios[8][4] = 9.62;

//Cazador
$promedios[9][0] = 8.42;
$promedios[9][1] = 8.42;
$promedios[9][2] = 8.79;
$promedios[9][3] = 9.41;
$promedios[9][4] = 9.62;

//Trabajador
$promedios[10][0] = 7.72;
$promedios[10][1] = 7.72;
$promedios[10][2] = 8.45;
$promedios[10][3] = 8.65;
$promedios[10][4] = 9.43;

//Pirata
$promedios[11][0] = 8.67;
$promedios[11][1] = 8.67;
$promedios[11][2] = 9.43;
$promedios[11][3] = 9.66;
$promedios[11][4] = 10.42;
?>
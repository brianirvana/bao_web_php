<title>BenderAO - Scripts Online</title>
<table border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><a href="index.php?op=Scripts/promedio"><font size=2><div align=center>Promedios Vida (<blink>NEW!</blink>)</div></font></a></td>
    </tr>
    <tr>
      <td background="images/fondotd.jpg" width="192" height="35"><a href="index.php?op=Scripts/apunalar"><font size=2><div align=center>Apu�alar</div></font></a></td>
    </tr>
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><a href="index.php?op=Scripts/domar"><font size=2><div align=center>Domar Animales</div></font></a></td>
    </tr>
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><i href=index.php?op=Scripts/index><font size=2 color=#CBB08D><div align=center>Golpe Critico (N/D)</div></font></i></td>
    </tr>
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><i href=index.php?op=Scripts/index><font size=2 color=#CBB08D><div align=center>Navegaci�n (N/D)</div></font></i></td>
    </tr>
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><i href=index.php?op=Scripts/index><font size=2 color=#CBB08D><div align=center>Da�o de Hechizos (N/D)</div></font></i></td>
    </tr>
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><i href=index.php?op=Scripts/index><font size=2 color=#CBB08D><div align=center>Robar (N/D)</div></font></i></td>
    </tr>
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><i href=index.php?op=Scripts/index><font size=2 color=#CBB08D><div align=center>Mineria (N/D)</div></font></i></td>
    </tr>
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><i href=index.php?op=Scripts/index><font size=2 color=#CBB08D><div align=center>Drop (N/D)</div></font></i></td>
    </tr>
    <tr>
      <td  background="images/fondotd.jpg" width="192" height="35"><i href=index.php?op=Scripts/index><font size=2 color=#CBB08D><div align=center>Paralizar con Golpe (N/D)</div></font></i></td>
    </tr>
    <tr>
      <td  background="images/fondotdfinal.jpg" width="192" height="41"><i href=index.php?op=Scripts/index><font size=2 color=#CBB08D><div align=center>Ocultar (N/D)</div></font></i></td>
    </tr>
</table>

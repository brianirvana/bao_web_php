<?php
$maxrazas = 4;
$razas[0] = 'Gnomo';
$razas[1] = 'Elfo Oscuro';
$razas[2] = 'Elfo';
$razas[3] = 'Humano';
$razas[4] = 'Enano';
?>
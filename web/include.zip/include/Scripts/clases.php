<?php
$maxclases = 11;
$clases[0] = 'Mago';
$clases[1] = 'Clerigo';
$clases[2] = 'Guerrero';
$clases[3] = 'Asesino';
$clases[4] = 'Ladron';
$clases[5] = 'Bardo';
$clases[6] = 'Druida';
$clases[7] = 'Bandido';
$clases[8] = 'Paladin';
$clases[9] = 'Cazador';
$clases[10] = 'Trabajador';
$clases[11] = 'Pirata';
?>
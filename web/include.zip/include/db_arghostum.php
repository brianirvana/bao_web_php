<?php

global $id;
global $tipo;
$dbhost = "190.0.163.3";
$dbname = "arghostum";
$dbusername = "arghostum";
$dbpass = "x#KOm,2!*+Si";
	
// Charset
$charset = "uft-8";
$textchars = 480;
$tekst_datum = "d-m-Y";
$start = 0;
$end = 6;
$image_folder = "img";
$mail="arghostum@gmail.com";
$site="Arghostum";

$dberror = "Error 321 conectando a la base de datos!";

?>
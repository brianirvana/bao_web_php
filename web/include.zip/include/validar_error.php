<p align="center"><b><font size="4">�ATENCI�N!</font></b><br>

	Disculpe, ha habido un error al intentar verificar su e-mail en la base de daos.<br>
	
</p> 

<p align="center">
	<a href="?op=StaffActual" onclick="window.scrollTo(0,0); return false">
	(ir arriba)</a><font color="#008000"> </font>
</p>
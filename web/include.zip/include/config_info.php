<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

<?php

global $id;
global $tipo;
global $op;
$dbhost = "localhost";
$dbname = "benderao_web";
$dbusername = "benderao_user";
$dbpass = "x#KOm,2!*+Si";
	
// Charset
$charset = "uft-8";
$textchars = 480;
$tekst_datum = "d-m-Y";
$start = 0;
$end = 6;
$image_folder = "img";
$mail="soporte.bender@gmail.com";
$site="Bender AO";

$dberror = "Error 321 conectando a la base de datos!";

// Administration
$edit = "Editar";
$admin_error = "Error";
$title_error = "Tenes que ingresar un titulo";
$text_error = "Tenes que ingresar un cuerpo";
$noticias='noticias';
$tabla_online='tabla_online';
$tabla_visitas='tabla_visitas';
$visitas_anteriores="150";


?>
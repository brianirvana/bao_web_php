<?
    mb_http_output("windows-1252");
    header("Content-Type: text/html; charset=". mb_http_output());
?>

<html>
<head><meta charset="windows-1252">
<meta http-equiv="Content-Language" content="es">
</head>

<p align="center"><b><a href="JavaScript:leerDatos('StaffActual.php')">
<font color="#008000" size="4">Staff Actual</font></a></b></p>
<p align="center"><b><a href="JavaScript:leerDatos('StaffHistorico.php')">
<font color="#008000" size="4">Staff Historico</font></a></b></p>

<html>


<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
</head>
<p align="center">
<b>
<a href="JavaScript:DelDiv()">Volver</a><font color="#008000">
</font></b>
</p>
<p align="center"><b>DIOSES: (cant: 19)</b><br>
<br>

1 ALLPORT (Creador de BenderAO y Ex Director)<br>
2 GENGIS (Ex Director)<br>
3 VANCAKE (Ex Director)<br>
4 ANSHELUS (Ex Director)<br>
5 ASLAN<br>
6 BLACKO<br>
7 BLUR<br>
8 D O L<br>
9 ELEKTRA<br>
10 ELNICK<br>
11 GAMMA<br>
12 MIGHTY<br>
13 MANTI<br>
14 NOODLE<br>
15 OCIRARA<br>
16 PARMENIDO<br>
17 SNUMA<br>
18 BLANKENESEE<br>
<br>
<br>
<b>SEMIDIOSES: (cant: 40)</b><br>
<br>
1 ATHENAS<br>
2 ARCHANGEL<br>
3 BALTHIER<br>
4 BELFALAS<br>
5 BLAZE<br>
6 BODZIN<br>
7 BRISA<br>
8 CYRIL<br>
9 DARKIAN<br>
10 DARK GANDALF<br>
11 DORIATH<br>
12 DRATILOBFER<br>
13 DIM<br>
14 EL SERENO<br>
15 FALAMEEZAR<br>
16 FRITH<br>
17 HELLEN<br>
18 KITO<br>
19 LADY CLAIRE<br>
20 LERZHAK<br>
21 MUNPHIS<br>
22 NAHAR<br>
23 NGUENECHEN<br>
24 NETHER<br>
25 SANCHEZ<br>
26 SEREGHIM<br>
27 SHIRA<br>
28 SOFI<br>
29 TALK<br>
30 TONCHO<br>
31 VERDAGUER<br>
32 ZAPHOID<br>
33 FALAMEEZAR<br>
34 CYRIL<br>
35 LESTER<br>
36 BODZIN<br>
37 BEN<br>
38 ODAVLAM<br>
39 HIMMOD<br>
40 SIR LUCK<br>
41 BALDARK<br>
<br>
<b>CONSEJEROS: (cant: 24)</b><br>
<br>
1 AIXA<br>
2 AMYSON<br>
3 AZRAEL<br>
4 BENNY<br>
5 BATATA<br>
6 COTI<br>
7 ELDORETH<br>
8 INDIECITA<br>
9 JERO<br>
10 LAUTAH<br>
11 LAZARO<br>
12 MANUH<br>
13 MERY LEEN<br>
14 NALLIS<br>
15 ODAVLAM<br>
16 OSQI<br>
17 TORCHO<br>
18 SHAW<br>
19 SHULY<br>
20 SUMMER<br>
21 MAUROLOMAS<br>
22 SHAW<br>
23 KHELUM<br>
24 POTASIUM<br>
25 FYCKEDF<br>
26 INSU<br>
<br>
<b>ROLEMASTERS: (cant: 12)</b><br>
<br>
<b>DIOSES:</b><br>
<br>
1 ALENOR RATHRIEL<br>
2 FAREWELL<br>
3 MATEO<br>
4 NIRVELL<br>
5 PLATON<br>
6 ZHAK<br>
7 D O L<br>
8 LUCYBEL<br>
9 BACOO<br>
10 JESUS<br>
11 ASLEEN<br>
12 RAMLEIRD<br>
<br>
<b>SEMIDIOSES: (cant: 6)</b><br>
<br>
1 EDRAHIL<br>
2 NOLDORETH RATHRIEL<br>
3 RUMAH<br>
4 HEWIK<br>
5 NIGHAR<br>
6 THEEBAN<br>
<br>
<br>
<b>CONSEJEROS: (cant: 8)</b><br>
<br>
1 ANNATAR TINTAEL<br>
2 KAGNUS KHAN<br>
3 KITO<br>
4 KUKO<br>
5 RAZIEL<br>
6 SCREEHNSHOT<br>
7 THRORIEL<br>
8 WAKI<br>
9 AMENAKTHE<br>
10 ARTAINS ELENDIL<br>
11 HEWIK<br>
12 INSANE<br>
13 SESHAT<br>
</p>

<p align="center">
<a href="?op=StaffHistorico" onclick="window.scrollTo(0,0); return false">
(ir arriba)</a><font color="#008000"> </font>
</p>

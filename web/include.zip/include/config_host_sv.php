<?php
$dbhost = "localhost";
$dbname = "benderao_web";
$dbuser = "benderao_user";
$dbpass = "x#KOm,2!*+Si";
?>

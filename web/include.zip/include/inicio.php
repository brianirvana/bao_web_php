<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="noticias.css" rel="stylesheet" media="screen" type="text/css" />
</head>

<body>
	<div class="cuerpo-wrapper" id="cuerpo">
    	<div id="cuerpo-inicio" class="page">
	        <div id="panel-complete" align=center>
            	<BR />
    	    	<div id="noticia_titulo">
	            	<font color="#626262">PROXIMA TRANSMISIÓN DOM 13-10 - 18:30HS</font>
	            </div>
                <div id="bar"></div>
                <br />
<iframe width="640" height="480" src="//www.youtube.com/embed/0NCEacsTJ2Q?rel=0" frameborder="0" allowfullscreen></iframe>
				<?php
				/*
				<iframe width="640" height="480" src="//www.youtube.com/embed/0NCEacsTJ2Q?rel=0" frameborder="0" allowfullscreen></iframe>
				<object type="application/x-shockwave-flash" height="640" width="900" id="live_embed_player_flash" data="http://www.twitch.tv/widgets/live_embed_player.swf?channel=allsleague" bgcolor="#000000"><param name="allowFullScreen" value="true" /><param name="allowScriptAccess" value="always" /><param name="allowNetworking" value="all" /><param name="movie" value="http://www.twitch.tv/widgets/live_embed_player.swf" /><param name="flashvars" value="hostname=www.twitch.tv&channel=allsleague&auto_play=true&start_volume=25" /></object>
			<br /><a href="http://www.twitch.tv/allsleague" target="_blank"><b>Ir a Twitch...</b></a> */ ?>
			
            </div>
            <?php
			/*
	        <div id="panel-sidebar">
    	    	<div id="video_titulo">
	            	ÚLTIMOS VIDEOS
	            </div>
				<?php include("youtube.php"); ?>
            </div>
			*/
			?>
            
        </div>
    </div>
</body>
</html>
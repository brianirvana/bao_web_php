
<p><b>Staff de Prensa</b><br><br>
Director de Prensa<br>
Sadgasm<br>
Raditz<br><br>

Encargados<br>
About<br>
Cempurano<br>
Crissaegrim<br>
Fycked<br>
Insu<br>
Parmenido<br>
Raditz<br>
Shycker<br>
</p>


<html>
<head><meta charset="windows-1252">

    <link rel="shortcut icon" href="http://www.bender-online.com.ar/bender/images/favicon.ico" type="image/x-icon" />
</head>

<br>          
  <TABLE cellSpacing=0 cellPadding=0 width="100%">
              <TBODY>
              <TR vAlign=top>
                      <TD vAlign=top align=middle width="100%" height="100%">
                        <TABLE cellSpacing=0 cellPadding=0 width="95%" 
                        align=center border=0>
                          <TBODY>
                          <TR>
                            <TD class=entrevistas1>
                              <TABLE width="100%">
                                <TBODY>
                                <TR vAlign=top>
                                <TD class=titulo vAlign=top align=middle 
                                colSpan=2><A class=entrevistas1 
                                href="?op=Reglamento#penas">
								<font color="#008000">Ver 
                                Sistema de Penas</font></A></TD></TR>
                                <TR vAlign=top>
                                <TD class=titulo vAlign=top align=middle 
                                colSpan=2 height=10></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U><STRONG>ACERCA DEL 
								REGLAMENTO.</STRONG></U></P></FONT></TD></TR>
                                <TR>
                                <TD height=9 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><STRONG>Validez del 
                                reglamento.</STRONG></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1.1.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Este reglamento posee validez 
								desde su publicaci�n y hasta nuevo aviso, 
								revocando cualquier reglamento anterior.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1.1.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Por el solo hecho de conectarse 
								a un Servidor Oficial de Bender Online o 
								descargarse nuestro software, el usuario acepta 
								el deber de dar cumplimiento a las cl�usulas 
								contenidas en el presente.<BR><BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Reglas y sus 
                                actualizaciones.</B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1.2.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El staff de Bender Online se 
								reserva el derecho de suprimir, agregar o 
								modificar cl�usulas del presente reglamento, 
								seg�n lo crea conveniente, sin necesidad de 
								previo aviso.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1.2.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El desconocimiento de las 
								reglas aqu� contenidas o de sus actualizaciones, 
								no podr� ser invocado, de ning�n modo, como 
								justificaci�n frente a un incumplimiento de las 
								mismas.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1.2.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Cuando el reglamento sea 
								actualizado, esto ser� anunciado en la secci�n 
								de Noticias de la Web. Bastar�n las simples 
								palabras &quot;Reglamento Actualizado&quot;. Es obligaci�n 
								del usuario chequear la Web antes de entrar al 
								juego para confirmar la existencia de 
								modificaciones al presente.<BR><BR><BR><BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U><B>REGLAMENTACI�N DE 
                                USUARIOS.</B></U></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Creaci�n de 
                                personajes.</B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Sobre los nombres de los 
								Personajes: A la hora de crear un personaje es 
								importante tener en cuenta que &quot;Bender Online&quot; 
								es un mod de Argentum Online, un juego de 
								fantas�a y rol medieval. Por ello los personajes 
								creados deber�n tener un nombre acorde a la 
								tem�tica del juego, evitando cualquier tipo 
								modernismo o alusi�n alguna a elementos 
								manifiestamente incompatibles con el rol 
								medieval. Los nombres pueden surgir de la 
								imaginaci�n del usuario o bien ser tomados de la 
								historia o la mitolog�a, pero siempre 
								manteniendo una cierta ambientaci�n temporal, y 
								dentro de la tem�tica del Juego.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Adem�s de lo prescripto en el 
								apartado anterior, a continuaci�n se hace un 
								peque�o listado, meramente enunciativo, de los 
								tipos de nombres que no ser�n aceptados por el 
								Staff, a los fines de servir de gu�a al usuario 
								al momento de crear su personaje:</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>No se permitir�n alusiones a 
								ning�n tipo de droga (inclusive pegamentos), 
								bebida alcoh�lica, cigarrillos, ni a estados 
								inducidos por drogas o similares.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Asimismo no estar�n permitidos 
								nombres que contengan alusiones raciales de tono 
								discriminatorio, o que hagan referencia a 
								estados f�sicos o mentales insultantes hacia el 
								propio due�o y/o su personaje, o para con otros 
								usuarios.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Tambi�n ser�n prohibidos los 
								nombres de los cuales se pueda inferir que hacen 
								clara referencia a alg�n producto, marca, modelo 
								o empresa que sea de p�blico y notorio 
								conocimiento con el fin de publicitarlo. Tampoco se permitir�n alusiones a 
								programas de televisi�n de la actualidad, 
								conjuntos musicales, equipos de f�tbol, etc.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Estar�n prohibidos, adem�s, los 
								nombres que por su similitud a los de los 
								miembros del Staff pueden prestar a confusiones, 
								o que puedan ser entendidos como una burla hacia 
								los mismos.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>No se podr� crear personajes 
								cuyos nombres contengan cualquier tipo de 
								alusi�n al sexo, lenguaje grosero, callejero, 
								chabacano o agresivo; as� como tampoco se 
								permitir�n referencias a hechos de la vida real 
								que podr�an ser consideradas como 
								discriminatorias, como por ejemplo &quot;Limpio 
								Inodoros&quot;.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>No estar� permitida la alusi�n 
								a posturas pol�ticas de ninguna �ndole.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2.7</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>No estar� permitido el uso de 
								espacios entre letras de una misma palabra, ni 
								el uso de los dobles espacios para dividir 
								palabras, ni ninguna otra combinaci�n de 
								espacios. Ejemplo: &quot;J+U+A+N&quot; o bien 
								&quot;JUAN++MANUEL&quot;, en donde los signos mas (+) 
								valen por un espacio.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.2.8</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>S� estar�n permitidos los n�meros 
								romanos al final del nombre, ejemplo: Ricardo III (Ricardo Tercero) o Lu�s X (Lu�s D�cimo). 
								Tambi�n estar� permitido el Uso de los t�rmino 
								sir, Mr., Jr., etc.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Estas mismas reglas rigen 
								tambi�n para los nombres que se les asignen a 
								los CLANES con excepci�n de la regla 2.1.2.7 
								siempre y cuando el TAG con espacios m�ltiples 
								no contenga impl�cita la intenci�n de imitar a 
								otro nombre de clan y se preste a confusi�n.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Para la apreciaci�n de las 
								prohibiciones enumeradas en los apartados 
								precedentes, se podr�n tener en cuenta 
								variaciones m�nimas en las letras.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Cualquier usuario con un 
								personaje de nombre inadecuado podr� ser 
								obligado a cambiar su nombre o baneado en forma 
								definitiva, seg�n las circunstancias del caso. 
								En un caso ofensivo por ejemplo, el personaje 
								ser� baneado definitivamente o temporalmente 
								seg�n los administradores y su criterio.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.1.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Creaci�n de personajes con 
								fines ajenos al juego: Los personajes sobre los 
								que se puede deducir que han sido creados con 
								fines ajenos al juego, o entorpecedores del 
								desarrollo del mismo, -tales como realizaci�n de 
								piquetes, publicidad de otros servers, insultos 
								hacia el staff o el juego, usar el mismo como 
								medio de acercar guardias a personajes 
								criminales, etc.- podr�n, adem�s de ser baneados 
								sin previo aviso, ser castigados con el bloqueo 
								de la IP.</P></FONT></TD></TR>
                                <TR>
                                <TD height=2 width="3%"></TD></TR>
                                <TR>
                                <TD height=2 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Identificadores 
                                personales.</B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.2.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Ser�n considerados 
								&quot;identificadores Personales&quot; los datos que 
								acrediten a un usuario como due�o de un 
								personaje. En la actualidad, el �nico 
								identificador Personal existente en Bender 
								Online, es el nombre y a pellido con el que est� registrada 
								la cuenta de la persona. El mismo debe cumplir con los 
								requisitos referentes al registro de personajes.<BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.2.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>En la actualidad, la cuenta de un 
								personaje no puede ser modificada por el usuario. Es de 
								absoluta responsabilidad del usuario el uso criterioso 
								de la misma, no habiendo lugar a reclamo alguno en 
								caso de la p�rdida de la cuenta personal 
								por el pr�stamo, robo o hurto de la misma.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.2.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El uso de un Identificador
								Personal falso, inv�lido , o distinto, provoca que el 
								usuario no tenga forma de probar la propiedad 
								de la cuenta y por ende todos sus personajes y pertenencias.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.2.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Estos identificadores son la 
								�nica herramienta mediante la cual el usuario 
								puede solicitar cualquier tr�mite o pedido 
								referente a un personaje o una cuenta; por lo tanto, 
								cualquier hecho o factor que imposibilite al 
								usuario para utilizar su identificador, le 
								quitar� toda posibilidad de llevar a cabo los 
								mismos.<BR><BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Explotaci�n de bugs y uso de 
                                programas externos no 
                                autorizados.</B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.3.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Queda terminantemente prohibido 
								la explotaci�n de cualquier tipo de bug o 
								utilizaci�n de software externo no autorizado, 
								como ser macros, clientes editados, 
								aceleradores, perif�ricos configurables que 
								alteren funciones del juego, etc.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.3.1.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>De acuerdo a la gravedad de la 
								explotaci�n de un bug, se podr�n aplicar tres tipos de 
								penas:<BR>a) El baneo temporal del personaje involucrado o la cuenta.<BR>b) El baneo definitivo del personaje involucrado o la cuenta. <BR>c) 
                                Tolerancia Cero para los casos que los 
								Administradores o DSGMS 
                                entiendan pertinente en raz�n de la conducta 
                                ilegal reiterada, o da�os temporales/permanentes en el servidor, con intenci�n destructiva o da�ina hacia el mismo.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.3.1.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los GMs deber�n aplicar las 
								penas de acuerdo a lo establecido por el 
								&quot;Sistema de penas&quot; vigente, a menos que exista 
								contraorden de una autoridad superior; puesto 
								que los Administradores y/o Directivos del Staff podr�n aplicar 
								penas especiales de acuerdo a lo que ellos 
								entiendan necesario.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.3.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>La explotaci�n de un bug por 
								parte de un usuario debe ser reportada al Staff. 
								El hecho de NO reportar un bug es una violaci�n 
								directa a la participaci�n como &quot;betatester&quot;, y 
								puede ser causa de la expulsi�n inmediata y 
								permanente del usuario en la Comunidad.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.3.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Quienes oculten informaci�n 
								referente a cualquiera de estos puntos ser�n 
								considerados c�mplices y se les podr� aplicar la 
								misma pena que&nbsp; al/los autor/es del hecho.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.3.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El uso de software externo, no 
								publicado por el Staff en la p�gina oficial o el 
								foro oficial de Bender-Online.com.ag � benderao.com, es 
								responsabilidad de los usuarios. Quienes 
								descarguen software, aplicaciones o cualquier 
								otro archivo/programa publicado dentro del juego o foro, 
								por otros usuarios, se expone a riesgos bajo su 
								propia responsabilidad. El Staff no tiene ni tendr� 
								relaci�n con dichas publicaciones y no se har� 
								responsable de las mismas.<BR><BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Macro 
                                aceptable.</B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.4.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>�nicamente se permite el uso 
								del macro de forma asistida, que esta 
								incorporado al cliente - activable presionando 
								F7, F8 y F9- para realizar actividades de trabajo tales 
								como: dar golpes, lanzar magias o flechas, talar, pescar, minar, carpinter�a y 
								herrer�a. La obtenci�n de recompensas de 
								criaturas, experiencia o skills, no se 
								consideran actividades de trabajo.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.4.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Asimismo, los macros para 
								trabajar s�lo podr�n utilizarse de manera 
								asistida, esto quiere decir que el usuario debe 
								estar frente a la PC durante la utilizaci�n del 
								mismo.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.4.2.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Se considera en estado de 
								macreo inasistido a todo usuario que est� 
								realizando una actividad repetitiva, o cualquier 
								otra actividad que se haga sin el control del 
								usuario por m�s de 90 segundos. El GM/Centinela podr� 
								determinar esto de acuerdo al Manual de 
								Procedimientos.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.4.2.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El caso de una imposibilidad 
								especial que no permita responder al usuario 
								ante la presencia del GM/Centinela no ser� excusa para 
								evadir la sanci�n. Estas &quot;imposibilidades 
								especiales&quot;, que suelen describir los usuarios, 
								son el riesgo que ellos mismos asumen por el 
								hecho de utilizar un macro.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.4.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Est� terminantemente prohibida 
								la utilizaci�n de macros de trabajo externos. 
								Para actividades de trabajo se utilizar� el 
								macro que trae incorporado el cliente, haciendo 
								uso de la tecla F8.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.4.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>La pena aplicable al personaje 
								que utiliza un macro no aceptado, puede 
								extenderse, tambi�n, a los personajes que se 
								supone han sido directamente beneficiados por el 
								macreo; es decir a los otros personajes del 
								usuarios que macrea. Esto ser� determinado por 
								los directivos del Staff.<BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Otros actos pasibles de 
                                sanci�n. </B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U>Bloqueos a la libre 
                                circulaci�n:</U></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.1.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Est� terminantemente prohibido 
								bloquear la libre circulaci�n de otro usuario 
								por cualquier sector p�blico del juego. El 
								bloqueo a un usuario, para que sea sancionable, 
								debe realizarse indefectiblemente en condiciones 
								tales que el personaje atrapado no tenga 
								posibilidad alguna de liberarse por sus propios 
								medios o de atacar al usuario, mascota o NPC que 
								lo encierra; o que en el caso de que al atacarlo 
								pierda su status de ciudadano.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.1.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Dentro de esta prohibici�n se 
								encuentran comprendidas las siguientes 
								circunstancias: los encierros en lugares 
								cerrados para pedir objetos; el encierro de un 
								ciudadano con otro ciudadano para que lo ataque 
								un criminal; los realizados por 
								personajes que no pueden ser atacados (por ej. 
								porque son de la misma facci�n, porque el 
								atrapado no est� en condiciones de pelear, 
								porque es zona segura, etc.) y los encierros a 
								personajes muertos, dejando a �stos sin 
								posibilidad de circular libremente con el fin de 
								estorbar.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.1.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Detenerse sobre un objeto ca�do 
								o arrojado al suelo, estando el personaje 
								muerto, ya no es considerado bloqueo de la libre 
								circulaci�n.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.1.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>La utilizaci�n maliciosa de 
								mascotas para bloquear a otro personaje, lo 
								mismo que para bloquear un acceso, un camino o 
								un teleport, de manera que cause 
								congestionamiento o imposibilite la libre 
								circulaci�n de los usuarios, ser� considerado 
								bloqueo, siempre y cuando los personajes 
								afectados no tengan la posibilidad de atacar la 
								mascota sin perder su status.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.1.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>La utilizaci�n de personajes 
								vivos&nbsp; para mover el paso de un personaje 
								muerto, con la finalidad de que otro personaje 
								no pueda circular libremente, ser� considerado 
								Bloqueo (Esto incluye usar los personajes 
								muertos para mover a otros personajes muertos). 
								Lo mismo si el personaje muerto es usado para 
								entorpecer el libre 
								desenvolvimiento de un personajes vivo, sea 
								interponi�ndose en su camino, o movi�ndose para 
								generarle lag, o por el simple hecho de 
								molestarlo<BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=6 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.1.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Tambi�n ser� considerado 
								bloqueo la acci�n de resucitar a un personaje 
								para luego paralizarlo e intentar robarle o bien 
								demorarlo en ese indefenso estado. Esto incluye 
								tambi�n resucitar a un usuario para volver a 
								matarlo con fin de molestar, robar puntos de 
								clan, sumar frags.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><b><U>Interferencias con el 
                                trabajo del Staff:</U></b></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.2.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Mientras los GMs y Consejeros 
								se encuentren dentro del juego realizando sus 
								tareas o actividades, los usuarios no deber�n interferir de 
								ning�n modo, el libre desarrollo de las mismas.</P></FONT></TD></TR>
                                <TR>
                                <TD height=7 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.2.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Se encuentra prohibido atacar, 
								bajo ninguna circunstancia, al usuario que se 
								encuentra en consulta con un GM o Consejero. 
								Tambi�n est� prohibido interrumpir al 
								GM/Consejero o al usuario que est� en consulta, 
								durante la misma.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.2.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><b>Se proh�be, asimismo, llamar 
								un GM para pedirle objetos</b>, pedir que lo 
								hagan a un &quot;GM&quot;, que lo suban de nivel, que lo 
								lleve a determinado lugar, que le diga d�nde se 
								encuentra determinado personaje, preguntar por 
								el reset o pedir la realizaci�n de un evento 
								como duelos, quests, juegos, torneos o cambios de nicks, est� 
								prohibido.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.2.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>La utilizaci�n incorrecta de 
								los comandos que los personajes tienen para 
								tomar contacto con los GMS y/o Consejeros (como 
								ser el /GM y el /DENUNCIAR) que provoque una 
								molestia para el desempe�o de los mismos, 
								tambi�n ser� sancionada.</P></FONT></TD></TR>

                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.2.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>La utilizaci�n incorrecta del 
								comando que los usuarios tienen para 
								denunciar a otros usuarios cometiendo ilegalidades 
								provocando una molestia para el desempe�o 
								de los mismos, tambi�n ser� 
								sancionada, con ban permanente, o la sanci�n que los 
								administradores del juego crean pertinente.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><b><U>Respeto entre 
                                usuarios:</U></b></P></FONT></TD></TR>
                                <TR>
                                <TD height=3 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle height="26" width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.3.1</FONT></TD>
                                <TD width="96%" height="26"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Est� prohibido la utilizaci�n 
								de insultos entre los usuarios, como as� tambi�n 
								las faltas de respeto y las actitudes 
								discriminatorias. Se deja constancia de que el 
								Staff puede aplicar ante estas faltas, las penas 
								m�s rigurosas seg�n la gravedad del caso.</P></FONT></TD></TR>
                                <tr>
                                <TD vAlign=top align=middle height="25" width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.3.2</FONT></TD>
                                <TD width="96%" height="25"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Resucitar y matar a otro 
								usuario reiteradas veces a otro usuario puede 
								ser considerado como una provocaci�n agresiva 
								hacia el mismo y es un acto sancionable.</P></FONT></TD>
								</tr>
                                
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><b><u>Objetos de GMs, Objetos 
								Faccionarios, Objetos Especiales e intercambios de objetos:</u></b></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.5.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los objetos que posean los GMs, 
								que puedan caer de manera accidental o que 
								puedan estar en un intercambio con la presencia 
								e intervenci�n de un GM no deben ser tomados 
								por un usuario no involucrado en el intercambio. 
								Ante la indicaci�n del GM, los objetos deben ser 
								devueltos de inmediato, bajo apercibimiento del 
								baneo permanente del personaje. 
                                </P></FONT></TD></TR>
                                <tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.5.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los cuernos faccionarios y las 
								armaduras de segunda jerarqu�a son 
								intransferibles y no pueden intercambiarse ni 
								entregarse a un personaje que no haya sido 
								designado por la c�pula faccionaria o los 
								directivos pertinentes. Si el faccionario al que 
								le fuera entregado, es expulsado de la facci�n o 
								decide retirarse de la misma, debe entregar el 
								objeto a un Game Master o le ser� retirado. El 
								intercambio indebido de estos objetos puede 
								resultar en el baneo del personaje.</P></FONT></TD>
								</tr>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U>Robo de criaturas de 
                                entrenamiento:</U></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.6.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Entre personajes que no posean 
								el status &quot;Criminal&quot; estar� prohibido robarse 
								criaturas. Es decir que los personajes neutros 
								de status &quot;Ciudadano&quot; no pueden atacar a la 
								criatura que otro &quot;Ciudadano&quot; estaba atacando 
								para entrenar. Esto incluye tambi�n la 
								prohibici�n de &quot;curar&quot; la criatura, o paralizar 
								las mascotas del personaje que est� entrenando, 
								a los fines de perturbar su entrenamiento.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.6.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Lo dispuesto en este apartado 
								no se aplicar� para las criaturas que se 
								encuentren en &quot;zonas seguras&quot;. All� los NPCs 
								podr�n ser atacados por cualquiera, no 
								existiendo derecho alguno por atacar primero.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.6.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Se aclara que no existe 
								&quot;derecho de mapa&quot; por haber ocupado 
								anteriormente el mismo. El derecho del usuario 
								es s�lo por la criatura que est� atacando, no 
								por aquellas otras que est�n en el mapa que 
								ocupa.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.6.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Tambi�n se aclara que con el 
								sistema para evitar robos, la 
								criatura es de quien primero la ataca 
								(incluyendo inmovilizarla). Pero siempre se 
								tendr� en cuenta cu�l de los personajes es el 
								que tiene la intenci�n de robar. Por ejemplo, si 
								un guerrero est� yendo a la criatura y estando a 
								un par de tiles, un mago que aparece de un 
								rinc�n la paraliza, evidentemente �sta no ser� 
								del mago.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.7</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U>Ubicaci�n ilegal de 
                                criaturas y objetos:</U></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.7.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Estar� prohibido el acomodar 
								las criaturas existentes de modo tal que �stas 
								bloqueen una salida, paso o entrada, o bien 
								ataquen de modo inmediato a quien entra a un 
								mapa.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.8</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U>Comportamiento inadecuado en 
                                el Foro Oficial:</U></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.8.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Aquel usuario que a trav�s del 
								Foro oficial de Bender Online, tenga una conducta 
								temeraria para con el Staff y con los dem�s 
								miembros de la comunidad, utilizando ese lugar 
								para el insulto sistem�tico, como para la 
								acusaci�n falsa o injuriosa, como as� tambi�n 
								cualquier modo de falta de respeto y vejaci�n 
								hacia el Proyecto, ser� pasible de graves 
								sanciones por parte del Staff que pueden llegar 
								hasta el baneo de todos los personajes y la 
								aplicaci�n de &quot;Tolerancia Cero&quot;.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.8.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Aquel usuario que realice 
								p�blicamente acusaciones hacia un miembro del 
								Staff, siendo �stas infundadas (sin basarse en 
								hechos concretos), o de mero car�cter injurioso, 
								lo mismo que aqu�l que realice insinuaciones y 
								suspicacias incriminatorias hacia aquellos, ser� 
								pasible de graves sanciones por parte del Staff 
								que pueden llegar hasta el baneo de todos los 
								personajes, y la aplicaci�n de &quot;Tolerancia 
								Cero&quot;.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.9</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U>Sanciones extraordinarias a 
                                usuarios:</U></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.5.9.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los Administradores y Directivos del Staff de 
								Bender Online, a su criterio, podr�n aplicar sanciones 
								especiales, a los usuarios que, tanto en el 
								juego como en la vida en la comunidad, 
								demuestren un comportamiento y una actitud 
								injustificadamente hostil para con el juego, sus 
								autoridades o su comunidad; como as� tambi�n 
								aquellos usuarios que -sin llegar a violar 
								expresamente este reglamento- a trav�s de sus 
								actos y sus dichos, tanto dentro como fuera del 
								juego, perjudiquen el normal desenvolvimiento de 
								los jugadores, atenten contra la armon�a de la 
								comunidad, o menoscaben el desarrollo del juego 
								y agravien a su Staff. En estos casos tambi�n se 
								podr� aplicar la &quot;Tolerancia Cero&quot;.<BR><BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Comportamiento 
                                faccionario.</B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.6.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Sin perjuicio de las sanciones 
								que puedan aplicar las c�pulas faccionarias 
								(Consejo de Angrod y Concilio de las Sombras) a 
								los miembros que incumplan con las reglas 
								contempladas en este apartado, el Staff de GMs y 
								Consejeros tambi�n podr�n aplicar sanciones de 
								car�cter administrativo para los casos que 
								corresponda.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.6.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><u>Suma fraudulenta de frags:</u> 
								Est� prohibido los arreglos entre personajes a 
								los fines de sumar ciudadanos o criminales para 
								entrar a cualquier facci�n, o para subir de 
								rango dentro de �stas. En el caso de personajes 
								que a�n no se enlistaron, la pena ser� la 
								reducci�n a 0 de dicho contador y la 
								imposibilidad perpetua de enlistarse en la 
								facci�n que pretende. En el caso de personajes 
								ya enlistados, se le reducir� el contador de 
								frags al m�nimo permitido en su facci�n, y la 
								c�pula faccionaria podr� solicitar la expulsi�n 
								del mismo. Quien colabore con aqu�l -por 
								ejemplo, prest�ndose para morir reiteradas 
								veces- tambi�n ser� sancionado, y si es 
								faccionario podr� ser expulsado del misma.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.6.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los miembros del Ej�rcito Real 
								no podr�n colaborar de modo alguno, ni estar 
								pac�ficamente en un mismo mapa con ning�n 
								personaje que sea de status &quot;Criminal&quot;, como as� 
								tampoco los miembros de la Legi�n Oscura podr�n 
								hacerlo con personajes cuyo status sea el de 
								&quot;Ciudadano&quot;.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.6.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Quien pertenezca a cualquiera 
								de las dos facciones, deber� prestar 
								colaboraci�n a los personajes de su misma 
								facci�n que est�n combatiendo contra un 
								personaje neutro o de la facci�n opuesta. En 
								caso de no querer participar del combate deber� 
								alejarse lo suficiente del lugar, como para no 
								tener ocasi�n de ver el mismo.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.6.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Entre miembros de una misma 
								facci�n estar� prohibido robarse criaturas. Es 
								decir que no se puede atacar a la criatura que 
								el otro estaba atacando para entrenar. Tampoco 
								podr�n curar la criatura atacada, o paralizar o 
								atacar los elementales del que est� entrenando.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.6.5.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Lo expuesto en el apartado 
								anterior rige tambi�n por parte de los miembros 
								de la Armada Real, para con los Ciudadanos 
								neutros.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.6.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Las armaduras de Segunda 
								Jerarqu�a y los Cuernos Faccionarios no podr�n 
								ser comercializados o intercambiados por quien 
								los reciba, bajo pena de ser quitados, y 
								eventualmente sancionados los que participaron 
								en la operaci�n.<BR></P></FONT></TD></TR>
                                <tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                2.7</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>&nbsp;<b>Venta e intercambio de 
								Personajes</b><BR></P></FONT></TD>
								</tr>
								<tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.7.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Estar� permitida, tanto en el 
								juego como en el foro oficial, la publicidad de 
								ofertas de venta, compra y/o intercambio de 
								personajes, siempre y cuando se haga por los medios
								estipulados, como ser la secci�n "MERCADO" en caso
								de publicitar en el foro oficial (www.foro-bender.com.ar)<BR></P></FONT></TD>
								</tr>
								<tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.7.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Sanciones por fraudes en 
								venta, compra o intercambio de personajes:<BR></P></FONT></TD>
								</tr>
								<tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.7.2.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Conocimiento y explotaci�n de bugs del sistema: 
								ban permanente del personaje involucrado, la primera vez. 
								Si la persona, reincide en este accionar, el ban sera permanente 
								para todos los personajes registrados al e-mail (BAN EMAIL).<BR></P></FONT></TD>
								</tr>
								<tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.7.2.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Ofrecer personaje, para banear
								el mismo, y entorpecer la utilizaci�n de los mismos:
								Ban por 7 d�as la primera, permanente la segunda vez.<BR></P></FONT></TD>
								</tr>
								<tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.7.2.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Publicitar en juego con 
								personaje a vender o intercambiar: C�rcel y 
								advertencia al personaje.<BR></P></FONT></TD>
								</tr>
								<tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.7.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>ACLARACI�N: Las penas que se 
								apliquen por estas conductas &quot;in game&quot; 
								sumar�n como penas graves, y en el caso de llegar 
								a 2 penas, se penar� con baneo permanente del 
								e-mail de todos los personajes.<BR></P></FONT></TD>
								</tr>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Discrepancias con decisiones 
								del Staff de Bender Online.</B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Frente a una discrepancia con 
								el actuar del Staff, los usuarios tendr�n 
								derecho a presentar su opini�n o descargo, pero 
								deber�n hacerlo respetuosamente. La utilizaci�n 
								de lenguaje, vulgar, callejero, ofensivo, o en 
								caso de actitud descalificativa hacia los 
								miembros del Staff, har� que el usuario pierda 
								tal derecho de manera inmediata.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Si un usuario coloca un 
								descargo en un canal no estipulado, como ser el 
								foro, pierde el derecho a formular cualquier 
								descargo v�lido.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>En el caso de que el usuario 
								utilice un medio p�blico -como ser el Foro- con 
								el fin de que se disminuya una pena ya aplicada 
								o bien como modo de presi�n para el miembro del 
								Staff que lo sancion�, ser� considerado una 
								falta grave y podr� ser sancionado con la 
								prolongaci�n de la pena, o bien con la 
								perpetuidad de la misma, seg�n las 
								circunstancias del caso.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los descargos de los usuarios 
								deben referirse espec�ficamente a la pena que se 
								les aplic�. En virtud de lo dispuesto en el 
								apartado 2.8.3. del presente, los descargos que 
								se refieran a otros usuarios y a la aplicaci�n o 
								no aplicaci�n de penas a �stos, como argumento 
								para evitar la propia sanci�n, son inv�lidos. El 
								usuario DEBE REFERIRSE A SUS PROPIOS ACTOS CON 
								SU PROPIO PERSONAJE, no a los de terceros.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>En caso de hacerse menci�n a 
								una falta al procedimiento por parte de un GM o 
								miembro del staff, la misma debe esta 
								correctamente acreditada y detallada indicando 
								la hora y fecha del hecho; el usuario tambi�n 
								debe especificar las reglas quebrantadas por 
								parte del GM o miembro del staff.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.5.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los rumores y acusaciones sin 
								referencias a hechos s�lidos ser�n ignorados, 
								sin m�s, pudiendo ser de aplicaci�n en estos 
								casos lo dispuesto en el apartado 2.5.8.2 del 
								presente reglamento.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los canales de contacto con el 
								staff de GMs son �nicamente el sistema de /GM 
								Ayuda en el juego y el sistema de soporte. 
								Cualquier otro contacto por foros, mensajer�a 
								privada, chat, etc; no tendr� car�cter oficial 
								ni relevancia alguna. Los DSGMs podr�n 
								establecer cualquier otro canal seg�n lo crean 
								necesario.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.7</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los descargos en el juego, a 
								trav�s del /GM Ayuda, no podr�n durar m�s de 5 
								minutos. En caso de requerir m�s tiempo, el 
								usuario deber� realizar su descargo mediante el 
								sistema de soporte (http://bender-online.com.ar/ 
								secci�n Soporte), o bien v�a MP (Mensaje 
								Privado) en el foro 
								oficial (http://Bender-Online.com.ar/foro)</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.7.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>La informaci�n respecto de los 
								motivos de las sanciones se puede encontrar en 
								el juego mismo, a trav�s de la utilizaci�n del 
								comando &quot;/penas+nick del PJ&quot;.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.8.8</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Cualquier queja o descargo 
								deber� realizarse teniendo en cuenta que el 
								Staff se reserva, de modo absoluto, los derechos 
								de admisi�n y permanencia, raz�n por lo cual el 
								usuario no tendr� derecho a plantear ninguna 
								exigencia.<BR><BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>Expulsiones y 
                                sanciones.</B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>La sanciones ser har�n de 
								acuerdo al reglamento y sistema de penas, 
								siempre y cuando los DSGMs no decidan lo 
								contrario.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los DSGMs, por su cargo, poseen 
								la facultad de aplicar sanciones especiales 
								diferentes a las del &quot;Sistema de penas&quot;, seg�n 
								su criterio.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%" height="38"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.3</FONT></TD>
                                <TD width="96%" height="38"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El staff no est� obligado a 
								sancionar sistem�ticamente y de manera inmediata 
								a todos los usuarios que cometen una misma 
								falta, si no que lo har�n de acuerdo a su 
								tiempo, su convencimiento y disponibilidad para 
								verificar los hechos y aplicar la sanci�n, 
								pudiendo, adem�s, valorar en cada caso concreto 
								las circunstancias especiales que contenga. Por 
								ello podr� ocurrir que un personaje sea 
								sancionado por un hecho que cometi� tiempo 
								atr�s, sin que tenga por ello derecho a queja.</P></FONT></TD></TR>
                                <TR>
                                <TD height=7 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los descargos y excusas 
								referentes a sanciones se realizan de acuerdo a 
								los puntos contenidos en la regla 2.7.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%">
								<font size="1" face="Verdana">2.9.4.1</font></TD>
                                <TD width="96%"><font size="1" face="Verdana">
								Las sanciones se aplican a los personajes 
								independientemente de qui�n lo est� utilizando 
								al momento de la infracci�n. El pr�stamo de los 
								mismos es de exclusiva responsabilidad de los 
								usuarios.</font></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U>�Tolerancia Cero�</U>. Las 
								consecuencias de la aplicaci�n de esta pena 
								sobre un usuario son las siguientes:<BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Baneo definitivo de todos 
                                personajes que se puedan determinar que son de 
                                su propiedad.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Baneo definitivo de todos los 
                                personajes que est�n identificados con las 
                                casillas e-mail que se le 
                                conozcan.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Baneo definitivo de los 
                                personajes cuyo �ltimo IP. sea el del usuario 
                                sancionado.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Inhabilitaci�n de la IP del 
								infractor para ingresar al juego, y el baneo 
								definitivo del PC.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>En lo sucesivo se banear� 
                                cualquier personaje que, creado con 
                                posterioridad a la sanci�n, se pueda determinar 
                                que es del usuario en 
                                cuesti�n.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Baneo definitivo del personaje 
                                que se encuentre siendo usado por el usuario 
                                sancionado, sin importar a qui�n pertenezca el 
                                mismo.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5.7</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El alcance de la aplicaci�n de 
                                esta pena puede ser morigerada por los DSGMS, 
                                seg�n las circunstancias del 
                                caso.<BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>2.9.5.8</FONT></TD>
                                <TD width="96%"><font size="1" face="Verdana">
								Cualquier personaje implicado en el robo o 
								vaciamiento de otros personajes ser� baneado 
								hasta que el due�o pueda determinar su 
								desvinculaci�n del hecho, as� como los 
								personajes registrados al mismo email o 
								logueados desde la misma IP del culpable.</font></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><U><B>ACLARACIONES 
                                IMPORTANTES.</B></U></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El staff de Bender Online se 
								reserva el derecho de admisi�n y permanencia de 
								los usuarios en la Comunidad.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El Staff de Bender Online no es 
								responsable de las actitudes o accionares de los 
								usuarios del juego. Cada usuario es el �nico 
								responsable de sus propias acciones y actitudes.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El Staff de Bender Online no se 
								hace responsable por cualquier da�o ocasionado 
								por nuestro software, el mismo es instalado en 
								todo caso bajo propio riesgo del usuario.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.4</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Los GMs, Consejeros y personal 
								de soporte, no son empleados nuestros ni se 
								encuentran en posici�n remunerativa, y por ende 
								el Staff de Bender Online no es responsable por 
								su accionar.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.5</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El staff de Bender Online no 
								est� obligado a responder por fallas en el 
								servicio, ca�das del mismo o interrupciones sin 
								previo aviso, as� como cualquier mal 
								funcionamiento del juego.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.6</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El staff de Bender Online deja 
								constancia de que si los encargados del juego lo 
								entienden pertinente, a los efectos de proteger 
								el juego de la utilizaci�n ilegal de programas 
								externos por parte de los usuarios, se podr� 
								hacer uso de los medios necesarios para conocer 
								los programas que �stos ejecuten simult�neamente 
								con el juego.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.7</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Todos los servicios prestados 
								en Bender Online, son totalmente gratuitos, por 
								lo tanto el usuario no tiene derecho a crear 
								demandas, exigencias o reclamos. Estas demandas 
								y reclamos s�lo ser�n atendidos de acuerdo a la 
								buena voluntad, disponibilidad y posibilidades 
								de nuestra empresa. En caso de no estar de 
								acuerdo con el funcionamiento del servicio, las 
								actitudes de otros usuarios, as� como la de 
								nuestros personales, sus decisiones tomadas, 
								medidas aplicadas, el funcionamiento de los 
								servicios, administraci�n y direcci�n de los 
								mismos, como tambi�n respecto de la 
								administraci�n y direcci�n de nuestro personal y 
								la manera de actuar de las personas que 
								colaboran en este proyecto, el usuario s�lo 
								deber� abandonar nuestro servicio y borrar el 
								software instalado en su PC, sin posibilidad a 
								ninguna otra acci�n, o reclamo, a causa del 
								desacuerdo.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.8</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El cuidado y seguridad de los 
								personajes se hace mediante encriptaci�n de 
								claves, y mediante un sistema de recuperar 
								contrase�a, cambio de mail y borrado de 
								personajes que s�lo puede utilizar quien tenga 
								en su poder el e-mail puesto por el usuario.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.9.1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El staff no tiene ninguna 
                                relaci�n / obligaci�n / responsabilidad, con 
                                respecto a problemas de seguridad que pueda 
                                tener el usuario. La seguridad de la PC del 
                                usuario corresponder� a los due�os de la misma, 
                                as� como la de la cuenta de e-mail corresponder� 
                                a los due�os de la mencionada cuenta y los 
                                proveedores de la misma.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.9.2</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>El Staff no tiene ninguna 
								relaci�n / obligaci�n / responsabilidad, con 
								respecto a problemas de seguridad que pueda 
								tener el usuario. La seguridad de la PC del 
								usuario corresponder� a los due�os de la misma, 
								as� como la de la cuenta de e-mail corresponder� 
								a los due�os de la mencionada cuenta y los 
								proveedores de la misma.<br>
								3.9.2 En caso de robo de e-mail, el usuario 
								deber� tratar el problema con la empresa 
								proveedora del mismo. El staff de Bender Online 
								no tiene relaci�n en absoluto con dichas 
								empresas, y por lo tanto no tiene raz�n por la 
								cual tomar acci�n alguna al respecto.<br>
								<BR></P></FONT></TD></TR>
                                <tr>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>3.9.3</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>Bender Online es una empresa 
								sin fines de lucro, la cual recibe donaciones 
								por parte de sus usuarios con el �nico fin de 
								mantener la comunidad y el servidor online.<br>
								- La donaci�n se clasifica como un contrato 
								principal, consensual, traslativo de dominio, 
								unilateral, gratuito, en principio irrevocable, 
								entre vivos y, habitualmente, instant�neo y 
								formal solemne. Otra caracter�stica de este 
								contrato es que el donante no ser� responsable 
								de evicci�n a menos que se haya obligado 
								expresamente o que la donaci�n sea con cargo.<BR></P></FONT></TD>
								</tr>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD class=titulo vAlign=top align=middle 
                                colSpan=2 height=15></TD></TR>
                                <TR vAlign=top>
                                <TD class=titulo vAlign=top align=middle 
                                colSpan=2><font color="#008000"><b><A name=penas>Sistema de 
                                Penas</A></b></font></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>1</FONT></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P 
                                align=justify><b><u>Penas de Ban:</u></b></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"></TD>
                                <TD width="96%"><font face="Verdana" size="1">
								<b>1 Macros</b><br>
								1.1 Macros generales<br>
								Son aquellos que realizan tareas autom�ticamente 
								y de forma repetitiva pero sin alterar los 
								intervalo. Ban de 2 meses la primera vez y ban 
								permanente la segunda.<br>
								1.2 Macros acelerados. <br>
								Son aquellos que realizan tareas autom�ticamente 
								y de forma repetitiva de forma acelerada para 
								obtener beneficio de esto.
								Ban permanente.</font><p>
								<font face="Verdana" size="1"><b>2 Cheats</b><br>
								2.1 Ver Invisibles, Radar, Speedhack, Auto Vida, 
								Clientes modificados/inyectados.<br>
								Ban permanente.<br>
								<br>
								<b>3 Abuso de bugs</b><br>
								<u>3.1 Bugs Varios:</u> acomodar criaturas, saltar 
								mapas, cerrar paralizado<br>
								Ban de 7 d�as la primera vez, de 15 d�as la 
								segunda, y permanente la tercera. (con &quot;acomodar 
								criaturas&quot;, se refiere por ejemplo a cuando 
								voluntariamente se ubica a �stas de modo tal que 
								cuando otro usuario entra a un teleport la misma 
								lo ataque).<br>
								
								<u>3.3 Cortar intervalos:</u> (S�lo en casos que 
								la modificaci�n del intervalo sea alguna 
								metodolog�a que interfiera en la jugabilidad y/o 
								la utilizaci�n de programa externos que alteren 
								los mismos)<br>
								Ban permanente o temporal, seg�n la gravedad del 
								mismo.<br>
								<u>3.4 Otros Bugs</u><br>
								Ban permanente o temporal, seg�n la gravedad del 
								mismo.</font></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%">
								<font face="Verdana, Arial, Helvetica, sans-serif" size="1">
								3.6</font></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>REINCIDENCIA:</B> El 
                                personaje que alcance la TERCERA PENA DE BANEO, 
                                por las razones que fuesen, ser� baneado de modo 
                                PERMANENTE.<BR><BR><BR></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%">
								<font face="Verdana, Arial, Helvetica, sans-serif" size="1">
								3.7</font></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B><U>Penas de 
                                C�rcel:</U></B></P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%">&nbsp;</TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify>4 Penas de C�rcel<br>
								4.1 Bloqueos<br>
								* Interferencias al trabajo del Staff.<br>
								* Insultos y agresiones. Este punto enmarca 
								inclusive el dirigirse a otro usuario con 
								t�rminos peyorativos as� est� vivo o muerto. (C�rcel 30 minutos la primera vez, ban permanente la segunda vez, tolerancia cero la tercera vez)<br>
								* Resucitar y matar reiteradas veces al oponente 
								que carece de posibilidades de luchar.<br>
								* Tomar objetos de GMs o de intercambios ante 
								�stos.<br>
								* Robo de NPC de entrenamiento (Incluye curar 
								criatura y paralizar elementales).<br>
								* Mal uso del comando denunciar o /GM.<br>
								* Utilizar el pj para ayudar a sumar Frags a 
								otro.<br>
								<br>
								Todas las penas de c�rcel, ser�n de no menos de 20 minutos, 
								a excepci�n de la pena 2.5.2.5 que es de m�nimo 40 minutos. 
								A la 3� pena de c�rcel, se 
								aplicar� 7 d�as de baneo por primera acumulaci�n 
								de penas. a la 4� pena de c�rcel se aplicara ban 
								de 15 d�as por segunda acumulaci�n de penas. Y a 
								la quinta vez se le aplicar� el baneo 
								definitivo del personaje. Los baneos que sean 
								penas de c�rcel agravadas, contar�n como 
								c�rceles en la sumatoria para los baneos 
								provenientes de la misma.<br>
								4.2 In conductas Faccionarias<br>
								Se aplicar� una ADVERTENCIA por cada vez que se 
								encuentre al personaje en infracci�n. A la 1ra 
								ADVERTENCIA el personaje ser� expulsado de la 
								facci�n, debiento �ste pedir el perd�n faccionario por el medio vigente para hacerlo.<br>
								<br>
								5 Faltas de Respeto Graves<br>
								5.1 Discriminaci�n del tipo xenofobica o 
								religiosa.<br>
								* Amenazas f�sicas.<br>
								Ban permanente.</P></FONT></TD></TR>
                                <TR>
                                <TD height=5 width="3%"></TD></TR>
                                <TR vAlign=top>
                                <TD vAlign=top align=middle width="3%"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">2.2</font></TD>
                                <TD width="96%"><FONT 
                                face="Verdana, Arial, Helvetica, sans-serif" 
                                size=1>
                                <P align=justify><B>* Conductas Anti 
                                Faccionarias</B><BR>Se aplicar� una <u>ADVERTENCIA</u> 
                                por cada vez que se encuentre al personaje en 
                                infracci�n. A la 3ra ADVERTENCIA el personaje 
                                ser� expulsado de la 
                                facci�n.</P></TD></TR>
                                </TBODY></TABLE></TD></TR></TBODY></TABLE></TD>

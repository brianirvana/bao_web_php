<p align="center">

<b>Estad�sticas personales de personajes:</b><br>

<IFRAME NAME="I1" SRC="http://bender-online.com.ar/estadisticas/index.php" width="418" height="437" frameborder=0 scrolling=no></IFRAME>
<br>
<b>Ranking de personajes:</b><br>

<IFRAME NAME="estadisticas" SRC="http://bender-online.com.ar/estadisticas/Nivel.html" width="418" height="675" frameborder=0 scrolling=yes></IFRAME>
</body>
</p>
<?php
$dbhost = "localhost";
$dbname = "benderao_web";
$dbusername = "benderao_user";
$dbpass = "x#KOm,2!*+Si";
$dberror = "Error en la db."
?>
<p align="center">

<b>Estad�sticas personales de personajes:</b><br>
<br>
<b>Ranking de personajes:</b><br>

<IFRAME NAME="estadisticas" SRC="http://bender-online.com.ar/web/include/stats.php" width="418" height="1200" frameborder=0 scrolling=yes></IFRAME>

</body>
</p>
<head>
</head>
Test1
<body>
<script text="text/javascript" src="efecto.js">Test</script>
</body>
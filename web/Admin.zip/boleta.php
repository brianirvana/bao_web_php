<form method="post" action="https://gateway.payulatam.com/ppp-web-gateway/pb.zul" accept-charset="UTF-8">
  <input type="image" border="0" alt="" src="http://www.payulatam.com/img-secure-2015/boton_pagar_pequeno.png" onClick="this.form.urlOrigen.value = window.location.href;"/>
  <input name="buttonId" type="hidden" value="pUsaIIDR7bNGIjWkBwG/5XKJbwYby7rLwbtVd92MCEVMC72hoso2nQ=="/>
  <input name="merchantId" type="hidden" value="609583"/>
  <input name="accountId" type="hidden" value="612562"/>
  <input name="description" type="hidden" value="Servicio de Programación por Adelantado"/>
  <input name="referenceCode" type="hidden" value="Developer"/>
  <input name="amount" type="hidden" value="500.00"/>
  <input name="tax" type="hidden" value="0.00"/>
  <input name="taxReturnBase" type="hidden" value="0"/>
  <input name="currency" type="hidden" value="ARS"/>
  <input name="lng" type="hidden" value="es"/>
  <input name="displayShippingInformation" type="hidden" value="YES"/>
  <input name="sourceUrl" id="urlOrigen" value="" type="hidden"/>
  <input name="buttonType" value="SIMPLE" type="hidden"/>
  <input name="signature" value="78404990a4569c6a7963e11db54e55d558d9fb976fe1ca1afc0ca6f9612485f6" type="hidden"/>
</form>
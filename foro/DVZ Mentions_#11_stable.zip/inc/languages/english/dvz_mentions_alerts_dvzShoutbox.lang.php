<?php

$l['myalerts_dvz_mentions_dvzShoutbox_alert'] = '{1} mentioned you in Shoutbox (#{2}).';
$l['myalerts_setting_dvz_mentions_dvzShoutbox'] = 'Receive alert when mentioned in the Shoutbox?';

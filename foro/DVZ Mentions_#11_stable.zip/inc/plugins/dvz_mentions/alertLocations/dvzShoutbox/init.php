<?php

require_once 'core.php';
require_once 'formatter.php';

// hook files
require_once 'hooks_frontend.php';

// hooks
\dvzMentions\addHooksNamespace('dvzMentions\Alerts\dvzShoutbox\Hooks');
